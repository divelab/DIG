import os

__version__ = '0.0.4'
debug = False
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
