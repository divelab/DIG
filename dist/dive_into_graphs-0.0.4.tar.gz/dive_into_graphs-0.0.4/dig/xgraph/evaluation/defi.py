"""
FileName: definitions.py
Description: 
Time: 2020/7/28 12:22
Project: GNN_benchmark
Author: Shurui Gui
"""
import os

ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
