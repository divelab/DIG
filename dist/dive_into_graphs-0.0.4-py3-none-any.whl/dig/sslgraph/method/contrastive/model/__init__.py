from .contrastive import Contrastive
from .infograph import InfoGraph
from .grace import GRACE
from .graphcl import GraphCL
from .mvgrl import MVGRL, NodeMVGRL